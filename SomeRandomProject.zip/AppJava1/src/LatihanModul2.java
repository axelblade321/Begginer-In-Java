/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kyle Rayner
 * OwO What is this??
 */
public class LatihanModul2 {
    public static void main(String[] args) {
        float a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q;
        
        a = 1;
        b = 2;
        c = 3;
        d = 4;
        e = 5;
        f = 6;
        g = 7;
        h = 8;
        i = 9;
        j = 10;
        k = 11;
        l = 12;
        m = 13;
        n = 14;
        o = 15;
        p = 16;
        q = 17;
        
        //COntoh FOrmula
        a +=b;
        System.out.println(a);
        
        c +=b-c;
        System.out.println(c);
        
        d +=(e*f);
        System.out.println(d);
        
        g -=(h/i)+g;
        System.out.println(g);
        
        h +=i++;
        System.out.println(h);
        
        j = ++k;
        System.out.println(j);
        
        l -= --m+ n--;
        System.out.println(l);
        
        o +=p++ + ++q;
        System.out.println(o);
    }
}
