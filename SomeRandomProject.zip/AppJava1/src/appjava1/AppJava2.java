/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appjava1;

/**
 *
 * @author Kyle Rayner
 */
public class AppJava1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("STIKI MALANG");
        String Nama = "Gewa Pratama";
        System.out.println(Nama);
        int Semester = 2;
        System.out.println(Semester);
        float ran = 0.99f;
        System.out.println(ran);
        char letter = 'G';
        System.out.println("letter");
        boolean TF = true;
        System.out.println(TF);
        
    }
    
}
