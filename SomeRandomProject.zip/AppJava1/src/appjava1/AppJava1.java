/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appjava1;

/**
 *
 * @author Kyle Rayner
 */
public class AppJava1 {

    /**
     * @param args the command line arguments
     */
    static final int day_in_week = 7;
    public static int test = 10;
    static final float phi = 3.14f;
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("days=" + day_in_week);
        // OwO,OwO,OwO,OwO,OwO,OwO,OwO,OwO,OwO,OwOOwO,OwO,OwO,OwO
        System.out.println("STIKI MALANG");
        String Nama = "Gewa Pratama";
        System.out.println(Nama);
        int Semester = 2;
        System.out.println(Semester);
        float ran = 0.99f;
        System.out.println(ran);
        char letter = 'G';
        System.out.println("letter");
        boolean TF = true;
        System.out.println(TF);
        
        String name = "Gewa Pratama";
        System.out.println("Hello " + name);
        
        String first = "StikI";
        String last = "Malang";
        String full = first + " " + last;
        System.out.println(full);
        
        int angka = 20 + 30;
        System.out.println(angka);
        
        int x = 2, y = 3, z = 4;
        System.out.println(x + y + z);
        
        int ang_int = 2147483647;
        System.out.println(ang_int);
        
        byte ang_byte = 127;
        System.out.println(ang_byte);
        

    }
    
}
