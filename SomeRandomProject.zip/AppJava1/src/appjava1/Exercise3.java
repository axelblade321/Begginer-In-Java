/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appjava1;
/**
 *
 * @author Kyle Rayner
 * OwO What is That??
 */
public class Exercise3 {
    public static void main(String[] args) {
        Float ipk = 3.40f;
        char pd1 = 'A';
        
        if (ipk>3.00) {
            if (pd1=='A') {
                System.out.println("Ambil SKS 24 dan boleh ikut lomba");
                
            }
            else{
            System.out.println("Ambil SKS 21");
            }
            
        } else {
            System.out.println("Ambil SKS 18");
        }
    }
}
