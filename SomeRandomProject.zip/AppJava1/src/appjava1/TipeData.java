/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appjava1;

/**
 *
 * @author Kyle Rayner
 */
public class TipeData {
    public static void main(String[] args) {
        long data1 = Long.MAX_VALUE;
        int data2 = 2235641;
        short data3= Short.MAX_VALUE;
        byte data4 =34;
        float data6 = 1.733f;
        double data5 = 4.967;
        char data7 = 'C';
        boolean data8 = true;
        
        System.out.println("Nilai Long : "+data1);
        System.out.println("Nilai Int : "+data2);
        System.out.println("Nilai Short : "+data3);
        System.out.println("Nilai Byte : "+data4);
        System.out.println("Nilai Double : "+data5);
        System.out.println("Nilai FLoat : "+data6);
        System.out.println("Nilai Char : "+data7);
        System.out.println("Nilai Boolean : "+data8);
    }
    
}
