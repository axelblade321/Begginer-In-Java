/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kyle Rayner
 */
public class LatihanModul2No2 {
    public static void main(String[] args) {
        int a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x;
         
        a = 1;
        b = 2;
        c = 3;
        d = 4;
        e = 5;
        f = 6;
        g = 7;
        h = 8;
        i = 9;
        j = 10;
        k = 11;
        l = 12;
        m = 13;
        n = 14;
        o = 15;
        p = 16;
        q = 17;
        r = 18;
        s = 19;
        t = 20;
        u = 21;
        v = 22;
        w = 23;
        x = 24;
        
        //Program
          a = b & c;
          System.out.println(a);
          
          d = e &(f&g);
          System.out.println(d);
          
          h=(i&j)&(k&l);
          System.out.println(h);
          
          m=n|o;
          System.out.println(m);
          
          p=q&(r&s);
          System.out.println(p);
          
          t=(n&v)&(w&x);
          System.out.println(t);
    }
}
